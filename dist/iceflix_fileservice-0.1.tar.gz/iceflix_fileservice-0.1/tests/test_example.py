def test_always_true():
    assert True

#----------------------------------------
"""
self.event_init.wait(time_v)

#logging.warning(self.servant.openFile("866975148d3dbedcd545f92bf9a27317b456c5cff3bf8fe5dd8c0d58b29f9cfe", "hhhhh"))
self.servant.removeFile("866975148d3dbedcd545f92bf9a27317b456c5cff3bf8fe5dd8c0d58b29f9cfe", "hhhhh")

prox_open_file = self.servant.openFile("866975148d3dbedcd545f92bf9a27317b456c5cff3bf8fe5dd8c0d58b29f9cfe", "hhhhh")
logging.warning("prox_open_file: %s ",str(prox_open_file))
"""
#----------------------------------------